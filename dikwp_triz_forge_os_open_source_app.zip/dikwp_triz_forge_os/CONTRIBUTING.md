# Contributing

Contributions should preserve DIKWP attribution, maintain offline-first operation, and avoid adding network calls, hidden telemetry, dynamic code execution, or host mutation helpers to the core package.

Preferred contribution types:

- domain-specific contradiction templates
- safe inventive-principle mappings
- experiment-plan generators
- benchmark cases
- registry and TrustPassport metadata improvements
