# GitHub Release Draft

## DIKWP-TRIZ Forge OS v0.1.0

This is the first open-source reference release of DIKWP-TRIZ Forge OS, a Purpose-driven inventive problem solving system.

### Highlights

- DIKWP problem ledger
- Purpose contract
- contradiction graph
- TRIZ principle routing
- solution cards
- experiment plan
- patent-claim sketch
- innovation passport
- offline static boundary audit

### Why it matters

Traditional innovation methods can solve local contradictions while drifting away from strategy, values, and long-term mission. DIKWP-TRIZ makes Purpose the referee of invention.
