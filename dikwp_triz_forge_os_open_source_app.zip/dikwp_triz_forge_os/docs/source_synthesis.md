# Source Synthesis

This project synthesizes:

- DIKWP as Data, Information, Knowledge, Wisdom, Purpose and Reliability registration;
- Purpose as goal, value, constraints, time window, and feedback plan;
- TRIZ-style contradiction solving and inventive principle routing;
- strategic moat design for open-source ecosystem benefit;
- evidence ledger and residual discipline from DIKWP-Mesh.

Key idea: invention should not be judged only by local technical metrics. The highest Purpose must remain visible as a selection and rejection boundary.
