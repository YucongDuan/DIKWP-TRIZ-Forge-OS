# Strategic Moat Design

The system is deliberately designed as an open-core project.

## Open Core

- DIKWP ledger generator
- contradiction graph builder
- public principle routing
- solution-card generator
- experiment-plan generator
- schemas and tests

## Controlled Strategic Layers

These should not be given away as a fully open commodity without an ecosystem plan:

- official DIKWP-TRIZ registry;
- signed innovation passport issuer;
- certified industry contradiction templates;
- expert-reviewed principle mappings;
- enterprise workshop playbooks;
- patent/legal partner workflows;
- training and certification program;
- case library and benchmark datasets.

## Copycat Strategy

The goal is not to prevent all copying. The goal is to make honest users cite, register, certify, and partner, while making attribution removal visible.

Use TrustPassport, OriginMoat, and EcosystemRouter together with this project.
