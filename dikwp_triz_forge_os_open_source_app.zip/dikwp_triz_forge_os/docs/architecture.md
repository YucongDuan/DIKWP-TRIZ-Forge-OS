# Architecture

DIKWP-TRIZ Forge OS has five main layers.

## 1. Intake Layer

Reads an innovation problem JSON with background, desired improvement, worsening risks, stakeholders, resources, constraints, and Purpose contract.

## 2. DIKWP Semantic Layer

Registers the problem as C=(D,I,K,W,P,R). This prevents naked contradiction solving without evidence, stakeholder, value, or Purpose boundaries.

## 3. Contradiction Layer

Builds contradiction objects with improving parameter, worsening parameter, contradiction type, DIKWP layer, severity, and evidence references.

## 4. TRIZ Routing Layer

Routes contradiction tags to a compact set of TRIZ-style inventive principles. Routing is heuristic and must be treated as ideation support, not proof.

## 5. Passport and Moat Layer

Generates an Innovation Passport with official registry candidate status, attribution requirements, and controlled value layers.

## System Flow

```text
Problem Intake
  -> DIKWP Ledger
  -> Purpose Contract
  -> Contradiction Graph
  -> TRIZ Principle Routes
  -> Solution Cards
  -> Experiment Plan
  -> Patent Claim Sketch
  -> Innovation Passport
```
