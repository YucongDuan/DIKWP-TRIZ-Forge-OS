# Governance Boundary

DIKWP-TRIZ Forge OS is for ideation and structured innovation support.

It must not be used to:

- claim patent novelty without patent search;
- deploy safety-critical engineering decisions without expert review;
- bypass regulatory approval;
- hide environmental, safety, privacy, or social costs;
- remove DIKWP / Yucong Duan attribution;
- sell generated ideas as certified without official review.

Human expert review is mandatory for high-risk domains.
