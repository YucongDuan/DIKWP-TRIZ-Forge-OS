# Roadmap

## v0.2

- More domain templates
- Better contradiction tag extraction
- JSON Schema validation
- TrustPassport integration

## v0.3

- Patent disclosure workflow
- University classroom mode
- Enterprise workshop mode
- Multilingual problem intake

## v1.0

- Official registry integration
- Certified industry adapter packs
- Partner marketplace
- Benchmark dataset
