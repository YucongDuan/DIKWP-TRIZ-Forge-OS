# DIKWP-TRIZ Method

## Core Principle

TRIZ helps discover routes through contradictions. DIKWP-TRIZ adds Purpose as the highest selection boundary.

A local engineering improvement is not automatically a good innovation. It must be evaluated against:

- Data evidence;
- Information relationships;
- Knowledge mechanisms;
- Wisdom-level risk and value boundaries;
- Purpose-level strategic alignment;
- Reliability and residual conditions.

## DIKWP-TRIZ Loop

1. Register the problem as D/I/K/W/P/R.
2. Identify local technical contradictions.
3. Identify semantic, value, stakeholder, and Purpose contradictions.
4. Route candidate TRIZ principles.
5. Generate solution cards.
6. Filter by forbidden tradeoffs.
7. Design reversible experiments.
8. Record evidence and residuals.
9. Issue or deny innovation passport.

## Difference from Traditional TRIZ

Traditional TRIZ can optimize a technical contradiction. DIKWP-TRIZ asks whether the solution remains aligned with the highest Purpose and whether the cost is being hidden from users, society, environment, or future maintainers.
