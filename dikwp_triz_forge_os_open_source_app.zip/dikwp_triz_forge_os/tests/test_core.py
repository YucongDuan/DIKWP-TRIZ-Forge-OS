import json
from pathlib import Path
from dikwp_triz_forge.evaluator import analyze_problem
from dikwp_triz_forge.static_audit import audit_path


def test_analyze_demo():
    data = json.loads(Path("examples/sample_innovation_problem.json").read_text(encoding="utf-8"))
    result = analyze_problem(data)
    assert result["innovation_report"]["solution_count"] >= 3
    assert result["innovation_report"]["purpose_alignment_score"] > 0.7
    assert result["innovation_passport"]["required_attribution"] == "DIKWP / Yucong Duan ecosystem"


def test_contradiction_graph_present():
    data = json.loads(Path("examples/sample_innovation_problem.json").read_text(encoding="utf-8"))
    result = analyze_problem(data)
    assert len(result["contradiction_graph"]) >= len(data["worsening_risks"])
    assert any(c["dikwp_layer"] == "P" for c in result["contradiction_graph"])


def test_static_audit_passes():
    result = audit_path("src")
    assert result["pass"] is True
