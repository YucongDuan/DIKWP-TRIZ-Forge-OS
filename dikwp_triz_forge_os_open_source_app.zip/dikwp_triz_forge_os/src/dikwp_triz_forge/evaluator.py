from __future__ import annotations

from typing import Any, Dict, List, Tuple
from .models import ProblemInput, PurposeContract, Contradiction, PrincipleRoute, SolutionCard, InnovationReport, to_dict
from .dikwp import build_dikwp_problem_ledger
from .triz_data import TRIZ_PRINCIPLES, TAG_TO_PRINCIPLES
from .text_utils import contains_any, stable_id, clamp, tokenize

PRINCIPLE_LOOKUP = {pid: (name, desc) for pid, name, desc in TRIZ_PRINCIPLES}

RISK_KEYWORDS = {
    "safety": ["safe", "safety", "risk", "accident", "danger", "hazard", "安全", "风险"],
    "cost": ["cost", "price", "budget", "expensive", "成本", "预算"],
    "speed": ["speed", "latency", "fast", "delay", "throughput", "速度", "延迟"],
    "quality": ["quality", "accuracy", "reliability", "defect", "质量", "准确"],
    "energy": ["energy", "battery", "power", "carbon", "能耗", "电池", "续航"],
    "privacy": ["privacy", "personal", "secret", "credential", "隐私", "个人信息"],
    "reliability": ["reliable", "failure", "downtime", "robust", "故障", "可靠"],
    "complexity": ["complex", "integration", "interface", "复杂", "集成"],
    "ecology": ["green", "eco", "pollution", "recycle", "环保", "污染"],
    "governance": ["audit", "compliance", "approval", "governance", "审计", "合规"],
    "manufacturing": ["factory", "manufacturing", "production", "工业", "制造"],
    "medical": ["medical", "health", "patient", "clinical", "医疗", "健康"],
    "education": ["education", "learning", "student", "teacher", "教育", "学习"],
    "traffic": ["traffic", "transport", "vehicle", "mobility", "交通", "车辆"],
}


def load_problem(data: Dict[str, Any]) -> ProblemInput:
    pc = data.get("purpose_contract", {})
    purpose = PurposeContract(
        goal=pc.get("goal", ""),
        value=pc.get("value", ""),
        constraints=pc.get("constraints", []),
        time_window=pc.get("time_window", ""),
        feedback_plan=pc.get("feedback_plan", ""),
        forbidden_tradeoffs=pc.get("forbidden_tradeoffs", []),
    )
    return ProblemInput(
        problem_id=data.get("problem_id", stable_id("problem", data.get("title", "problem"))),
        title=data.get("title", "Untitled problem"),
        domain=data.get("domain", "general"),
        background=data.get("background", ""),
        desired_improvement=data.get("desired_improvement", ""),
        worsening_risks=data.get("worsening_risks", []),
        stakeholders=data.get("stakeholders", []),
        purpose_contract=purpose,
        evidence=data.get("evidence", []),
        resources=data.get("resources", []),
        constraints=data.get("constraints", []),
        current_system=data.get("current_system", {}),
        candidate_technologies=data.get("candidate_technologies", []),
    )


def infer_tags(problem: ProblemInput) -> List[str]:
    text = " ".join([
        problem.title,
        problem.domain,
        problem.background,
        problem.desired_improvement,
        " ".join(problem.worsening_risks),
        " ".join(problem.resources),
        " ".join(problem.constraints),
        problem.purpose_contract.goal,
        problem.purpose_contract.value,
        " ".join(problem.purpose_contract.constraints),
    ])
    tags = [tag for tag, kws in RISK_KEYWORDS.items() if contains_any(text, kws)]
    if not tags:
        tags = ["quality", "complexity", "governance"]
    return tags


def build_contradictions(problem: ProblemInput) -> List[Contradiction]:
    tags = infer_tags(problem)
    contradictions: List[Contradiction] = []
    base_text = f"{problem.title}|{problem.desired_improvement}|{problem.worsening_risks}"
    for idx, risk in enumerate(problem.worsening_risks or ["unknown worsening risk"]):
        layer = "W" if contains_any(risk, ["safety", "privacy", "compliance", "公平", "安全", "隐私", "合规"]) else "K"
        if contains_any(risk, ["purpose", "mission", "战略", "使命", "目标"]):
            layer = "P"
        severity = 0.55 + min(0.4, 0.08 * len(tokenize(risk)))
        contradictions.append(Contradiction(
            contradiction_id=stable_id("cx", f"{base_text}|{idx}|{risk}", 8),
            improving_parameter=problem.desired_improvement or "desired improvement",
            worsening_parameter=risk,
            contradiction_type="technical_value_purpose" if layer in ["W", "P"] else "technical",
            description=f"Improving '{problem.desired_improvement}' may worsen '{risk}'.",
            dikwp_layer=layer,
            severity=round(clamp(severity), 4),
            evidence_refs=[e.get("id", "evidence") for e in problem.evidence[:3]],
        ))
    # Add a Purpose contradiction if forbidden tradeoffs exist.
    for idx, tradeoff in enumerate(problem.purpose_contract.forbidden_tradeoffs):
        contradictions.append(Contradiction(
            contradiction_id=stable_id("pcx", f"{base_text}|forbidden|{idx}|{tradeoff}", 8),
            improving_parameter=problem.desired_improvement or "local optimization",
            worsening_parameter=tradeoff,
            contradiction_type="purpose_boundary",
            description=f"A local solution is invalid if it sacrifices forbidden tradeoff: {tradeoff}.",
            dikwp_layer="P",
            severity=0.95,
            evidence_refs=[e.get("id", "evidence") for e in problem.evidence[:3]],
        ))
    return contradictions


def route_principles(problem: ProblemInput, contradictions: List[Contradiction]) -> List[PrincipleRoute]:
    tags = infer_tags(problem)
    candidate_ids: List[int] = []
    for t in tags:
        candidate_ids.extend(TAG_TO_PRINCIPLES.get(t, []))
    if not candidate_ids:
        candidate_ids = [1, 23, 24, 35, 40]
    # Preserve order and uniqueness.
    uniq_ids = []
    for pid in candidate_ids:
        if pid not in uniq_ids:
            uniq_ids.append(pid)
    routes: List[PrincipleRoute] = []
    pc_score = problem.purpose_contract.completeness_score()
    for cx in contradictions:
        for pid in uniq_ids[:6]:
            name, desc = PRINCIPLE_LOOKUP[pid]
            purpose_boost = 0.12 if cx.dikwp_layer == "P" and pid in [23, 24, 32, 34, 39] else 0.0
            risk_fit = 0.55 + (0.1 if pid in [11, 23, 24, 26, 39] else 0.0) + (0.08 if cx.severity > 0.8 else 0.0)
            routes.append(PrincipleRoute(
                contradiction_id=cx.contradiction_id,
                principle_id=pid,
                principle_name=name,
                rationale=f"{name}: {desc} Applied to route contradiction '{cx.description}'.",
                purpose_fit=round(clamp(0.45 + 0.35 * pc_score + purpose_boost), 4),
                risk_fit=round(clamp(risk_fit), 4),
                evidence_need="prototype test + stakeholder review + evidence ledger update",
            ))
    return routes


def generate_solution_cards(problem: ProblemInput, contradictions: List[Contradiction], routes: List[PrincipleRoute]) -> List[SolutionCard]:
    by_cx: Dict[str, List[PrincipleRoute]] = {}
    for r in routes:
        by_cx.setdefault(r.contradiction_id, []).append(r)
    cards: List[SolutionCard] = []
    for cx in contradictions:
        rs = sorted(by_cx.get(cx.contradiction_id, []), key=lambda x: (x.purpose_fit + x.risk_fit), reverse=True)[:3]
        principle_ids = [r.principle_id for r in rs]
        names = [r.principle_name for r in rs]
        purpose_alignment = clamp(problem.purpose_contract.completeness_score() * 0.55 + sum(r.purpose_fit for r in rs) / max(1, len(rs)) * 0.45)
        risk = clamp(cx.severity * (1.0 - sum(r.risk_fit for r in rs) / max(1, len(rs)) * 0.45))
        feasibility = clamp(0.45 + 0.08 * len(problem.resources) + 0.05 * len(problem.candidate_technologies) - 0.12 * risk)
        novelty = clamp(0.35 + 0.07 * len(set(principle_ids)) + 0.08 * (1 if cx.dikwp_layer == "P" else 0))
        title = f"Purpose-aligned route for {cx.worsening_parameter[:60]}"
        mechanism = (
            f"Combine {', '.join(names)} to improve '{cx.improving_parameter}' while reducing the harm of "
            f"'{cx.worsening_parameter}'. The key move is to convert the contradiction into a staged, audited, "
            "purpose-filtered design experiment rather than a direct metric tradeoff."
        )
        cards.append(SolutionCard(
            solution_id=stable_id("sol", f"{problem.problem_id}|{cx.contradiction_id}|{principle_ids}", 8),
            title=title,
            contradiction_id=cx.contradiction_id,
            principle_ids=principle_ids,
            mechanism=mechanism,
            dikwp_mapping={
                "D": ["current constraint", "evidence refs", "measurable baseline"],
                "I": ["contradiction relation", "stakeholder difference", "risk boundary"],
                "K": ["TRIZ-style principle combination", "domain mechanism", "prototype test"],
                "W": ["forbidden tradeoff check", "safety/privacy/ecology review"],
                "P": problem.purpose_contract.goal,
                "R": "prototype-only; requires external validation",
            },
            purpose_alignment=round(purpose_alignment, 4),
            feasibility=round(feasibility, 4),
            risk=round(risk, 4),
            novelty_proxy=round(novelty, 4),
            experiment=f"Run a small reversible experiment for contradiction {cx.contradiction_id}; measure improvement, worsening risk, and Purpose fit before scaling.",
            kill_conditions=[
                "Solution violates a forbidden tradeoff.",
                "Evidence cannot support the claimed improvement.",
                "Prototype increases severe safety, legal, privacy, ecological, or social harm.",
                "Stakeholder review exposes an unregistered cost bearer.",
            ],
            recovery_path=[
                "Rollback to baseline.",
                "Reopen contradiction graph.",
                "Add missing evidence and stakeholder boundary.",
                "Run a lower-control experiment.",
            ],
        ))
    return sorted(cards, key=lambda c: (c.purpose_alignment + c.feasibility + c.novelty_proxy - c.risk), reverse=True)


def build_report(problem: ProblemInput, cards: List[SolutionCard], contradictions: List[Contradiction]) -> InnovationReport:
    if not cards:
        score = 0.0
        decision = "insufficient_problem_structure"
    else:
        score = sum(c.purpose_alignment + c.feasibility + c.novelty_proxy - c.risk for c in cards) / (3 * len(cards))
        score = clamp(score)
        if score >= 0.72:
            decision = "forge_ready_with_human_review"
        elif score >= 0.52:
            decision = "prototype_recommended_before_scaling"
        else:
            decision = "problem_reframing_required"
    residuals = [
        "No exhaustive patent search or freedom-to-operate review.",
        "No domain engineering certification.",
        "No real market validation.",
        "TRIZ route is a heuristic innovation scaffold.",
    ]
    return InnovationReport(
        problem_id=problem.problem_id,
        decision=decision,
        innovation_score=round(score, 4),
        purpose_alignment_score=round(problem.purpose_contract.completeness_score(), 4),
        contradiction_count=len(contradictions),
        solution_count=len(cards),
        recommended_solution_ids=[c.solution_id for c in cards[:3]],
        residuals=residuals,
        attribution={
            "model": "DIKWP-TRIZ",
            "ecosystem": "DIKWP / Yucong Duan",
            "notice_required": True,
            "trustpassport_recommended": True,
            "originmoat_recommended": True,
        },
    )


def analyze_problem(data: Dict[str, Any]) -> Dict[str, Any]:
    problem = load_problem(data)
    ledger = build_dikwp_problem_ledger(problem)
    contradictions = build_contradictions(problem)
    routes = route_principles(problem, contradictions)
    cards = generate_solution_cards(problem, contradictions, routes)
    report = build_report(problem, cards, contradictions)
    return {
        "problem": to_dict(problem),
        "dikwp_problem_ledger": to_dict(ledger),
        "contradiction_graph": to_dict(contradictions),
        "triz_principle_routes": to_dict(routes),
        "solution_cards": to_dict(cards),
        "innovation_report": to_dict(report),
        "purpose_contract": to_dict(problem.purpose_contract),
        "innovation_passport": {
            "passport_id": stable_id("dikwp-triz-passport", problem.problem_id),
            "project_name": problem.title,
            "purpose": problem.purpose_contract.goal,
            "decision": report.decision,
            "trust_level": "prototype_open_core",
            "official_registry_status": "candidate_unregistered",
            "required_attribution": "DIKWP / Yucong Duan ecosystem",
            "controlled_value_layers": [
                "official registry signature",
                "certified industry contradiction templates",
                "enterprise expert review",
                "patent/legal service integration",
                "training and partner certification",
            ],
        },
    }
