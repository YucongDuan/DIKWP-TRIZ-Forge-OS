from __future__ import annotations

import json
from .evaluator import analyze_problem


def main() -> None:
    import streamlit as st
    st.title("DIKWP-TRIZ Forge OS")
    st.caption("Purpose-driven contradiction routing and innovation passport generator")
    text = st.text_area("Paste problem JSON", height=400)
    if st.button("Analyze") and text.strip():
        result = analyze_problem(json.loads(text))
        st.json(result["innovation_report"])
        st.subheader("Top solution cards")
        for card in result["solution_cards"][:3]:
            st.write(card)

if __name__ == "__main__":
    main()
