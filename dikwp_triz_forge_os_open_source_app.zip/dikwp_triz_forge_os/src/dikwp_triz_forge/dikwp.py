from __future__ import annotations

from typing import Any, Dict, List
from .models import DIKWPRecord, ProblemInput


def build_dikwp_problem_ledger(problem: ProblemInput) -> DIKWPRecord:
    evidence_labels = [f"{e.get('id','ev')}: {e.get('claim','')}" for e in problem.evidence]
    return DIKWPRecord(
        D=[
            f"problem_title={problem.title}",
            f"domain={problem.domain}",
            f"background={problem.background}",
            f"desired_improvement={problem.desired_improvement}",
            *evidence_labels,
        ],
        I=[
            f"stakeholders={', '.join(problem.stakeholders)}",
            f"worsening_risks={', '.join(problem.worsening_risks)}",
            f"resources={', '.join(problem.resources)}",
            f"constraints={', '.join(problem.constraints)}",
        ],
        K=[
            "TRIZ-style contradiction routing",
            "DIKWP semantic registration",
            "Purpose contract scoring",
            "solution-card and experiment-plan generation",
        ],
        W=[
            "Do not optimize a local technical metric while violating the top-level Purpose.",
            "Do not delete real conflict; expose and route it.",
            "Use experiment gates before engineering deployment.",
            "Separate innovation ideation from patent/legal/engineering certification.",
        ],
        P={
            "goal": problem.purpose_contract.goal,
            "value": problem.purpose_contract.value,
            "constraints": problem.purpose_contract.constraints,
            "time_window": problem.purpose_contract.time_window,
            "feedback_plan": problem.purpose_contract.feedback_plan,
            "forbidden_tradeoffs": problem.purpose_contract.forbidden_tradeoffs,
        },
        R={
            "source_count": len(problem.evidence),
            "purpose_completeness": problem.purpose_contract.completeness_score(),
            "reliability": "prototype_local_heuristic",
            "borrowed_reliability": True,
            "residual": [
                "No patent novelty search performed.",
                "No engineering safety certification performed.",
                "TRIZ principle routing is heuristic, not a formal proof.",
            ],
        },
    )
