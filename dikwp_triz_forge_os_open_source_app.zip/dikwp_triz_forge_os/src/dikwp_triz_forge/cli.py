from __future__ import annotations

import argparse
import json
from pathlib import Path
from .evaluator import analyze_problem
from .reports import write_outputs, write_json
from .static_audit import audit_path


def cmd_analyze(args: argparse.Namespace) -> None:
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    result = analyze_problem(data)
    write_outputs(result, Path(args.out))
    print(json.dumps(result["innovation_report"], ensure_ascii=False, indent=2))


def cmd_static_audit(args: argparse.Namespace) -> None:
    result = audit_path(args.path)
    out = Path(args.out)
    write_json(out, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(prog="dikwp-triz-forge")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_analyze = sub.add_parser("analyze", help="Analyze an innovation problem and generate DIKWP-TRIZ outputs")
    p_analyze.add_argument("input", help="Path to problem JSON")
    p_analyze.add_argument("--out", default="outputs/demo", help="Output directory")
    p_analyze.set_defaults(func=cmd_analyze)

    p_audit = sub.add_parser("static-audit", help="Run offline static boundary audit")
    p_audit.add_argument("path", help="Source path")
    p_audit.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    p_audit.set_defaults(func=cmd_static_audit)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
