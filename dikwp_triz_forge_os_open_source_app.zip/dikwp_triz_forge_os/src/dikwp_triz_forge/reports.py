from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def build_experiment_plan(result: Dict[str, Any]) -> str:
    report = result["innovation_report"]
    cards = result["solution_cards"][:3]
    lines = [
        "# DIKWP-TRIZ Experiment Plan",
        "",
        f"Problem: {result['problem']['title']}",
        f"Decision: {report['decision']}",
        f"Innovation score: {report['innovation_score']}",
        "",
        "## Purpose Contract",
        f"- Goal: {result['purpose_contract']['goal']}",
        f"- Value: {result['purpose_contract']['value']}",
        f"- Time window: {result['purpose_contract']['time_window']}",
        f"- Feedback: {result['purpose_contract']['feedback_plan']}",
        "",
        "## Experiments",
    ]
    for idx, c in enumerate(cards, 1):
        lines += [
            f"### Experiment {idx}: {c['title']}",
            f"- Solution ID: `{c['solution_id']}`",
            f"- Principles: {', '.join(map(str, c['principle_ids']))}",
            f"- Mechanism: {c['mechanism']}",
            f"- Purpose alignment: {c['purpose_alignment']}",
            f"- Feasibility: {c['feasibility']}",
            f"- Risk: {c['risk']}",
            f"- Experiment: {c['experiment']}",
            "- Minimum measurements: baseline metric, improved metric, worsening-risk metric, stakeholder acceptance, rollback success.",
            "- Human gate: domain expert review before scaling.",
            "",
        ]
    lines += [
        "## Kill Conditions",
        "- Violation of forbidden tradeoffs.",
        "- Unsupported claims or no evidence ledger.",
        "- Severe safety, legal, privacy, ecological, or social harm.",
        "- Hidden cost bearer discovered.",
        "",
        "## Recovery",
        "- Roll back to baseline.",
        "- Reopen contradiction graph.",
        "- Add missing evidence and stakeholder review.",
        "- Re-run a lower-control prototype.",
    ]
    return "\n".join(lines)


def build_patent_claim_sketch(result: Dict[str, Any]) -> str:
    cards = result["solution_cards"][:3]
    lines = [
        "# Patent Claim Sketch / Invention Disclosure Draft",
        "",
        "This document is not a legal patent opinion. It is an invention-disclosure scaffold for attorney or patent-agent review.",
        "",
        f"Problem: {result['problem']['title']}",
        "",
        "## Technical Problem",
        result['problem'].get('background', ''),
        "",
        "## Purpose Boundary",
        result['purpose_contract']['goal'],
        "",
        "## Candidate Independent Claim Pattern",
        "A method/system for resolving a registered contradiction by constructing a DIKWP purpose contract, generating a contradiction graph, routing inventive principles, and selecting a solution through evidence-backed Purpose alignment and reversible experiment gates.",
        "",
        "## Candidate Dependent Claim Elements",
    ]
    for c in cards:
        lines.append(f"- A solution variant using TRIZ principles {', '.join(map(str, c['principle_ids']))}: {c['mechanism']}")
    lines += [
        "",
        "## Novelty Search Residual",
        "- No external patent search has been performed.",
        "- Need prior-art search across patent databases, academic literature, standards, and product manuals.",
        "- Need freedom-to-operate review before commercialization.",
    ]
    return "\n".join(lines)


def write_outputs(result: Dict[str, Any], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "dikwp_problem_ledger.json", result["dikwp_problem_ledger"])
    write_json(out_dir / "purpose_contract.json", result["purpose_contract"])
    write_json(out_dir / "contradiction_graph.json", result["contradiction_graph"])
    write_json(out_dir / "triz_principle_routes.json", result["triz_principle_routes"])
    write_json(out_dir / "solution_cards.json", result["solution_cards"])
    write_json(out_dir / "innovation_report.json", result["innovation_report"])
    write_json(out_dir / "innovation_passport.json", result["innovation_passport"])
    write_csv(out_dir / "contradiction_graph.csv", result["contradiction_graph"])
    solution_rows = [
        {
            "solution_id": c["solution_id"],
            "title": c["title"],
            "principles": ";".join(map(str, c["principle_ids"])),
            "purpose_alignment": c["purpose_alignment"],
            "feasibility": c["feasibility"],
            "risk": c["risk"],
            "novelty_proxy": c["novelty_proxy"],
        }
        for c in result["solution_cards"]
    ]
    write_csv(out_dir / "solution_scoreboard.csv", solution_rows)
    write_markdown(out_dir / "experiment_plan.md", build_experiment_plan(result))
    write_markdown(out_dir / "patent_claim_sketch.md", build_patent_claim_sketch(result))
