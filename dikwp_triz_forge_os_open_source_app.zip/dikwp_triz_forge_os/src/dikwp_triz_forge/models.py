from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class PurposeContract:
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str
    forbidden_tradeoffs: List[str] = field(default_factory=list)

    def completeness_score(self) -> float:
        fields = [self.goal, self.value, self.time_window, self.feedback_plan]
        base = sum(1 for x in fields if str(x).strip()) / len(fields)
        constraints_score = min(1.0, len(self.constraints) / 3) if self.constraints else 0.0
        return round(0.65 * base + 0.35 * constraints_score, 4)


@dataclass
class ProblemInput:
    problem_id: str
    title: str
    domain: str
    background: str
    desired_improvement: str
    worsening_risks: List[str]
    stakeholders: List[str]
    purpose_contract: PurposeContract
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    resources: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    current_system: Dict[str, Any] = field(default_factory=dict)
    candidate_technologies: List[str] = field(default_factory=list)


@dataclass
class DIKWPRecord:
    D: List[str]
    I: List[str]
    K: List[str]
    W: List[str]
    P: Dict[str, Any]
    R: Dict[str, Any]


@dataclass
class Contradiction:
    contradiction_id: str
    improving_parameter: str
    worsening_parameter: str
    contradiction_type: str
    description: str
    dikwp_layer: str
    severity: float
    evidence_refs: List[str]


@dataclass
class PrincipleRoute:
    contradiction_id: str
    principle_id: int
    principle_name: str
    rationale: str
    purpose_fit: float
    risk_fit: float
    evidence_need: str


@dataclass
class SolutionCard:
    solution_id: str
    title: str
    contradiction_id: str
    principle_ids: List[int]
    mechanism: str
    dikwp_mapping: Dict[str, Any]
    purpose_alignment: float
    feasibility: float
    risk: float
    novelty_proxy: float
    experiment: str
    kill_conditions: List[str]
    recovery_path: List[str]


@dataclass
class InnovationReport:
    problem_id: str
    decision: str
    innovation_score: float
    purpose_alignment_score: float
    contradiction_count: int
    solution_count: int
    recommended_solution_ids: List[str]
    residuals: List[str]
    attribution: Dict[str, Any]


def to_dict(obj: Any) -> Any:
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    if isinstance(obj, list):
        return [to_dict(x) for x in obj]
    if isinstance(obj, dict):
        return {k: to_dict(v) for k, v in obj.items()}
    return obj
