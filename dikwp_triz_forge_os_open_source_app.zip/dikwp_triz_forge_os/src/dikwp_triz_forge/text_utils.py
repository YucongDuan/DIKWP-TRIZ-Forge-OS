from __future__ import annotations

import re
from typing import Iterable, List


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip().lower())


def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z0-9_\u4e00-\u9fff]+", norm(text))


def contains_any(text: str, words: Iterable[str]) -> bool:
    t = norm(text)
    return any(norm(w) in t for w in words)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def stable_id(prefix: str, text: str, length: int = 10) -> str:
    import hashlib
    h = hashlib.sha256(text.encode("utf-8")).hexdigest()[:length]
    return f"{prefix}-{h}"
