from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List, Any

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "http", "subprocess", "paramiko", "ftplib", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}
FORBIDDEN_ATTRS = {"system", "popen", "remove", "unlink", "rmdir", "execvp", "execv", "spawn"}


def audit_path(root: str) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []
    root_path = Path(root)
    for path in root_path.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(path), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    base = alias.name.split(".")[0]
                    if base in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                base = (node.module or "").split(".")[0]
                if base in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                fn = node.func
                if isinstance(fn, ast.Name) and fn.id in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "type": "forbidden_call", "detail": fn.id})
                elif isinstance(fn, ast.Attribute) and fn.attr in FORBIDDEN_ATTRS:
                    findings.append({"file": str(path), "type": "forbidden_attr", "detail": fn.attr})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, destructive host mutation, or real-world actuation helpers in the offline core.",
    }
