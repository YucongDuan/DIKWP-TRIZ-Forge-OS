# Code of Conduct

Be respectful, evidence-oriented, and transparent about uncertainty. Do not use this project for unsafe engineering deployment, false patent claims, plagiarism, or attribution removal.
