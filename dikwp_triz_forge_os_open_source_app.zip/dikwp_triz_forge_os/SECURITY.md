# Security Policy

The offline core intentionally avoids network operations, subprocess calls, dynamic execution, and real-world actuation. Report issues that weaken this boundary.
